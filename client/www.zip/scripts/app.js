'use strict';
angular.module('main', [
  'ionic',
  'ionic.cloud',
  'ngCordova',
  'ui.router',
  // TODO: load other modules selected during generation
])
.config(function ($stateProvider, $urlRouterProvider, $ionicCloudProvider) {
  $ionicCloudProvider.init({
    core: {
      app_id: '824b4476'
    },

    'push': {
      'sender_id': '862559983879',
      'pluginConfig': {
        'android': {
          'iconColor': '#343434'
        }
      }
    }
  });

  // ROUTING with ui.router
  $urlRouterProvider.otherwise('/main/user');
  $stateProvider
    // this state is placed in the <ion-nav-view> in the index.html
    .state('main', {
      url: '/main',
      abstract: true,
      templateUrl: 'main/templates/tabs.html'
    })
    .state('main.user', {
      url: '/user',
      views: {
        'tab-user': {
          templateUrl: 'main/templates/user.html',
          controller: 'UserCtrl as ctrl'
        }
      }
    })
    .state('main.map', {
      url: '/map',
      views: {
        'tab-map': {
          templateUrl: 'main/templates/map.html',
          controller: 'MapCtrl as ctrl'
        }
      }
    })
    .state('main.camera', {
      url: '/camera',
      views: {
        'tab-camera': {
          templateUrl: 'main/templates/camera.html',
          controller: 'CameraCtrl as ctrl'
        }
      }
    })
    .state('main.debug', {
      url: '/debug',
      views: {
        'tab-debug': {
          templateUrl: 'main/templates/debug.html',
          controller: 'DebugCtrl as ctrl'
        }
      }
    });
})
.run(function(Location, $ionicPlatform) {
  Location.initLocation();
  $ionicPlatform.ready(function() {
    // Initialize plugin here
  });
});



'use strict';
angular.module('main')
.factory('Location', function ($rootScope, $http, $cordovaGeolocation, $cordovaDevice) {

  //var allPlayers = {};

  var sendLocation = function (userLocation) {
    $http({
      method: 'PUT',
      url: 'http://35.162.247.27:4000/locations',
      data: userLocation
    }).then(function (response) {
      console.log(response);
    }, function (err) {
      console.error(err);
    });
  };

  var getAllLocations = function () {
    if ($rootScope.locationOn === true) {
      $http.get('http://35.162.247.27:4000/locations')
      .success(function(data) {
        console.log('Data from get', data);
        $rootScope.$emit('rootScope:players', data);
      })
      .error(function (err) {
        console.log(err);
        $rootScope.$emit('rootScope:players', err);
      });

      setTimeout(getAllLocations, 5000);
    }
  };

  //cordova Geolocation functions
  var getUserLocation = function () {
    if ($rootScope.locationOn === true) {
      var posOptions = {timeout: 10000, enableHighAccuracy: false};
      $cordovaGeolocation
        .getCurrentPosition(posOptions)
        .then(function (position) {
          var device = $cordovaDevice.getDevice();
          var userLocation = {};
          userLocation.deviceId = device.uuid;
          userLocation.lat = position.coords.latitude;
          userLocation.lng = position.coords.longitude;
          $rootScope.$emit('rootScope:location', userLocation);
          sendLocation(userLocation);
          setTimeout(getUserLocation, 2500);
        }, function (err) {
          console.error(err);
        });
    }
  };

  var initLocation = function() {
    getUserLocation();
    getAllLocations();
  };

  return {
    getUserLocation: getUserLocation,
    sendLocation: sendLocation,
    getAllLocations: getAllLocations,
    initLocation: initLocation
  };
});

'use strict';
angular.module('main')
.controller('UserCtrl', function ($log, $ionicAuth) {

  this.user = {
    email: '',
    password: ''
  };
  this.updateResult = function (type, result) {
    $log.log(type, result);
    this.user.resultType = type;
    this.user.result = result;
  };

  var responseCB = function (response) {
    this.updateResult('Response', response);
  }.bind(this);

  var rejectionCB = function (rejection) {
    this.updateResult('Rejection', rejection);
  }.bind(this);

  // tries to sign the user up and displays the result in the UI
  this.signup = function () {
    $ionicAuth.signup(this.user)
    .then(responseCB)
    .catch(rejectionCB);
  };
  // tries to sign in the user and displays the result in the UI
  this.signin = function () {
    $ionicAuth.login('basic', this.user)
    .then(responseCB)
    .catch(rejectionCB);
  };
});

'use strict';
angular.module('main')
.controller('UserCtrl', function ($log, $http, $scope) {

  $scope.announcer = '';

  this.user = {
    username: ''
  };
  // tries to sign the user up and displays the result in the UI
  this.signup = function () {
    $scope.announcer = 'That username is already taken.';
    $http({
      method: 'GET',
      url: 'http://localhost:4000/users?username=' + this.user.username
    }).then(function (response) {
      if (response.status === 404) {
        $http({
          method: 'PUT',
          url: 'http://localhost:4000/users',
          data: this.user
        }).then(function (response) {
          console.log(response); //for linter
        }, function (err) {
          console.error(err);
        });
      } else {
        $scope.announcer = 'That username is already taken.';
      }
    });
  };

  this.signin = function() {
    $scope.announcer = 'User  does not exist, click the sign up button to create a new account';
    $http({
      method: 'GET',
      url: 'http://localhost:4000/users?username=' + this.user.username
    }).then(function (response) {
      if (response.status === 200) {
        //authenticate the user TODO: add google Auth stuff
        $scope.announcer = 'Logged in as ' + this.user.username;
      } else {
        //Prompt user to create a new account
        $scope.announcer = 'User  does not exist, click the sign up button to create a new account';
        console.log($scope.announcer);
      }
    }, function (err) {
      console.error(err);
    });
  };
});

'use strict';
angular.module('main')
.controller('ToggleCtrl', function ($http, $rootScope, $cordovaDevice) {

  $rootScope.locationOn = false;

  this.toggleLocation = function () {
    console.log('click', !$rootScope.locationOn);
    if ($rootScope.locationOn === false) {
      $rootScope.locationOn = true;
      $rootScope.$on('rootScope:location', function (event, data) {
        $http({
          method: 'PUT',
          url: 'http://35.162.247.27:4000/logs/in',
          data: data
        }).then(function (response) {
          console.log(response);
        }, function (err) {
          console.error(err);
        });
      });
    } else {
      $rootScope.locationOn = false;
      $http({
        method: 'PUT',
        url: 'http://35.162.247.27:4000/logs/out',
        data: {
          deviceId: $cordovaDevice.getDevice().uuid,
          lng: null,
          lat: null
        }
      }).then(function (response) {
        console.log(response);
      }, function (err) {
        console.error(err);
      });
    }
    $rootScope.$emit('rootScope: toggle', $rootScope.locationOn);
  };
});

'use strict';
angular.module('main')
.controller('PopupCtrl',function($scope, $ionicPopup, $timeout) {

// Triggered on a button click, or some other target
  $scope.showPopup = function() {
    $scope.data = {};

    // An elaborate, custom popup
    var myPopup = $ionicPopup.show({
      template: '<input type="password" ng-model="data.wifi">',
      title: 'Enter Wi-Fi Password',
      subTitle: 'Please use normal things',
      scope: $scope,
      buttons: [
        { text: 'Cancel' },
        {
          text: '<b>Save</b>',
          type: 'button-positive',
          onTap: function(e) {
            if (!$scope.data.wifi) {
              //don't allow the user to close unless he enters wifi password
              e.preventDefault();
            } else {
              return $scope.data.wifi;
            }
          }
        }
      ]
    });

    myPopup.then(function(res) {
      console.log('Tapped!', res);
    });

    $timeout(function() {
      myPopup.close(); //close the popup after 3 seconds for some reason
    }, 3000);
  };

  // A confirm dialog
  $scope.showConfirm = function() {
    var confirmPopup = $ionicPopup.confirm({
      title: 'Consume Ice Cream',
      template: 'Are you sure you want to eat this ice cream?'
    });

    confirmPopup.then(function(res) {
      if (res) {
        console.log('You are sure');
      } else {
        console.log('You are not sure');
      }
    });
  };

  // An alert dialog
  $scope.showAlert = function() {
    var alertPopup = $ionicPopup.alert({
      title: 'Don\'t eat that!',
      template: 'It might taste good'
    });

    alertPopup.then(function(res) {
      console.log('Thank you for not eating my delicious ice cream cone');
    });
  };
});

'use strict';
angular.module('main')
.controller('MapCtrl', function ($scope, $rootScope, $state, $cordovaGeolocation, Location) {
  $scope.latLng = {lat: null, lng: null};
  $scope.marker = null;
  $scope.players = {};
  $scope.currentLocation = {};

  var title = 'Nathan';
  var content = 'dynamic content, yo';
  var infowindow = new google.maps.InfoWindow({
    content: '<h1 class="title">See, ' + title + '?</h1><h3>' + content + '</h3>'
  });

  // object of other player's locations.  Expecing an object with deviceIds as a key and
  // {lat, lng, deviceId} as a value

  // function to render the map, this should only have to be called once
  // on the first location change
  $scope.renderMap = function(zoom, mapTypeId) {
    //we need an initial latLng to render the map, so grab the location once
    var options = {timeout: 10000, enableHighAccuracy: false};
    $cordovaGeolocation.getCurrentPosition(options)
    .then(function(position) {
      $scope.latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
      var mapOptions = {
        center: $scope.latLng,
        zoom: zoom,
        mapTypeId: mapTypeId,
        styles: [
          {elementType: 'geometry', stylers: [{color: '#242f3e'}]},
          {elementType: 'labels.text.stroke', stylers: [{color: '#242f3e'}]},
          {elementType: 'labels.text.fill', stylers: [{color: '#746855'}]},
          {
            featureType: 'administrative.locality',
            elementType: 'labels.text.fill',
            stylers: [{color: '#d59563'}]
          },
          {
            featureType: 'poi',
            elementType: 'labels.text.fill',
            stylers: [{color: '#d59563'}]
          },
          {
            featureType: 'poi.park',
            elementType: 'geometry',
            stylers: [{color: '#263c3f'}]
          },
          {
            featureType: 'poi.park',
            elementType: 'labels.text.fill',
            stylers: [{color: '#6b9a76'}]
          },
          {
            featureType: 'road',
            elementType: 'geometry',
            stylers: [{color: '#38414e'}]
          },
          {
            featureType: 'road',
            elementType: 'geometry.stroke',
            stylers: [{color: '#212a37'}]
          },
          {
            featureType: 'road',
            elementType: 'labels.text.fill',
            stylers: [{color: '#9ca5b3'}]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry',
            stylers: [{color: '#746855'}]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry.stroke',
            stylers: [{color: '#1f2835'}]
          },
          {
            featureType: 'road.highway',
            elementType: 'labels.text.fill',
            stylers: [{color: '#f3d19c'}]
          },
          {
            featureType: 'transit',
            elementType: 'geometry',
            stylers: [{color: '#2f3948'}]
          },
          {
            featureType: 'transit.station',
            elementType: 'labels.text.fill',
            stylers: [{color: '#d59563'}]
          },
          {
            featureType: 'water',
            elementType: 'geometry',
            stylers: [{color: '#17263c'}]
          },
          {
            featureType: 'water',
            elementType: 'labels.text.fill',
            stylers: [{color: '#515c6d'}]
          },
          {
            featureType: 'water',
            elementType: 'labels.text.stroke',
            stylers: [{color: '#17263c'}]
          }
        ]
      };

      $scope.map = new google.maps.Map(document.getElementById('map'), mapOptions);

      $rootScope.$on('rootScope:location', function (event, data) {
        if (event) { //for linter
          $scope.latLng = {lat: data.lat, lng: data.lng, deviceId: data.deviceId};
          $scope.renderPoint($scope.latLng, 'user');
        }
      });

      $rootScope.$on('rootScope:players', function (event, data) {
        $scope.renderAllPlayers(data);
      });
    })
    .catch(function(error) {
      console.log(error);
    });
    //TODO update the mapOptions with params, saved for reference for now
  };

  $scope.removeAllPoints = function() {
    for (var player in $scope.players) {
      $scope.players[player].setMap(null);
    }
    $scope.players = {};
  };


  $scope.renderAllPlayers = function(players) {
    //$scope.removeAllPoints();
    for (var player in players) {
      if (player !== 'length') {
        $scope.renderPoint({lat: players[player].lat, lng: players[player].lng, deviceId: players[player].deviceId}, 'player');
      }
    }
  };

  $scope.renderPoint = function(point, type) {
    //code to either set a new marker if it doesn't exist or move an already existing one
    var marker;
    var latLng = new google.maps.LatLng(point.lat, point.lng);

    if (!point.lat || !point.lng) {
      $scope.players[point.deviceId].setMap(null);
      $scope.players[point.deviceId] = null;
      return;
    }

    if (type === 'player' && $scope.latLng.deviceId !== point.deviceId && $scope.latLng.deviceId) {
      if (!$scope.players[point.deviceId]) {

        marker = new google.maps.Marker({
          animation: google.maps.Animation.BOUNCE,
          position: latLng
          //icon: 'ggm/pink_MarkerA.png'
        });

        marker.addListener('click', function() {
          infowindow.open($scope.map, marker);
        });

        $scope.players[point.deviceId] = marker;
        $scope.players[point.deviceId].setMap($scope.map);
      } else {
        $scope.players[point.deviceId].setPosition(latLng);
        // interpolatePoint($scope.players[point.deviceId]);
      }
    } else {
      //user render code
      if ($scope.marker) {
        $scope.marker.setPosition(latLng);
        // interpolatePoint($scope.marker);
      } else {
        marker = new google.maps.Marker({
          animation: google.maps.Animation.DROP,
          position: latLng
          //icon: 'ggm/blue_MarkerA.png'
        });

        $scope.marker = marker;
        $scope.marker.setMap($scope.map);
      }
    }
  };

  var init = function() {
    $scope.renderMap(18, google.maps.MapTypeId.ROADMAP);
  };

  function interpolatePoint (oldPoint) {
    var step = 1;
    var maxSteps = 10;
    var time = 500;
    deltaLat = (latLng.lat - oldPoint.lat) / maxSteps;
    deltaLng = (latLng.lng - oldPoint.lng) / maxSteps;

    while (maxSteps > step) {
      setTimeout(function() {
        oldPoint.setPosition(oldPoint.lat + deltaLat * step, oldPoint.lng + deltaLng * step);
        step++;
      }, time / maxSteps);
    }
    oldPoint.setPosition(latLng);
  }

  $rootScope.$on('rootScope: toggle', function () {
    if ($rootScope.locationOn === true) {
      if (!$scope.map) {
        init();
      }
      Location.initLocation();
    } else {
      $scope.removeAllPoints();
    }
  });
});

'use strict';
angular.module('main')
.controller('DebugCtrl', function ($log, $http, $timeout, Location, $rootScope, Config, $cordovaDevice, $scope, $ionicPush) {

  $log.log('Hello from your Controller: DebugCtrl in module main:. This is your controller:', this);

  // bind data from services
  this.Location = Location;
  this.ENV = Config.ENV;
  this.BUILD = Config.BUILD;
  // get device info
  ionic.Platform.ready(function () {
    if (ionic.Platform.isWebView()) {
      this.device = $cordovaDevice.getDevice();
    }
    $ionicPush.register().then(function(t) {
      return $ionicPush.saveToken(t);
    }).then(function(t) {
      console.log('Token saved:', t.token);
    });
  }.bind(this));

  // PASSWORD EXAMPLE
  this.password = {
    input: '', // by user
    strength: ''
  };
  this.grade = function () {
    var size = this.password.input.length;
    if (size > 8) {
      this.password.strength = 'strong';
    } else if (size > 3) {
      this.password.strength = 'medium';
    } else {
      this.password.strength = 'weak';
    }
  };
  this.grade();

  // Proxy
  $scope.proxyState = 'ready';
  this.proxyRequestUrl = Config.ENV.SOME_OTHER_URL + '/get';
  $rootScope.$on('latlngtest', function(event, data) {
    $scope.proxyState = 'Lat: ' + data.lat + 'Lng: ' + data.lng;
  });


  this.proxyTest = function () {
    $rootScope.$on('rootScope:players', function(event, data) {
      $scope.proxyState = data.length;
      console.log(event, data);
    });

    $scope.proxyState = '. . .';
    //$scope.proxyState = '...';
    this.Location.getAllLocations();
  };

  $scope.$on('cloud:push:notification', function(event, data) {
    var msg = data.message;
    alert(msg.title + ': ' + msg.text);
  });

});

'use strict';
angular.module('main')
.controller('CameraCtrl', function ($scope, $cordovaCamera) {
  $scope.takePhoto = function () {
    var options = {
      quality: 75,
      destinationType: Camera.DestinationType.DATA_URL,
      sourceType: Camera.PictureSourceType.CAMERA,
      allowEdit: true,
      encodingType: Camera.EncodingType.JPEG,
      targetWidth: 300,
      targetHeight: 300,
      popoverOptions: CameraPopoverOptions,
      saveToPhotoAlbum: false
    };

    $cordovaCamera.getPicture(options).then(function (imageData) {
      $scope.imgURI = 'data:image/jpeg;base64,' + imageData;
    }, function (err) {
      console.error(err);
    });
  };
});


'use strict';
angular.module('Assassin', [
  // load your modules here
  'main', // starting with the main module
]);
